# Copyright Niall Douglas 2005. Use, modification and 
# distribution is subject to the Boost Software License, Version 1.0.
# (See accompanying file LICENSE_1_0.txt or copy at 
# http:#www.boost.org/LICENSE_1_0.txt)

from SingleCodeUnit import SingleCodeUnit
import re
import os
import utils

# Definitions at which to split output
splitoutputs={}

#==============================================================================
# SplittableCodeUnit
#==============================================================================
class SplittableCodeUnit:
    '''
    Represents a single cpp file but where the implementation has been
    split across one or more actual output files. 
    '''
    
    def __init__(self, modulename, filename, interface_file):
        self.modulename = modulename
        self.filename = filename                # Dir where my output goes
        self.interface_file = interface_file    # My .pyste file
        self.myoutputs = {}                     # My output code units based on definition
        #print splitoutputs, modulename, filename, interface_file
        if interface_file:
            # Create the SingleCodeUnit's that make us up
            filenamebase = os.path.splitext(os.path.basename(self.interface_file))[0]
            fn = os.path.join(self.filename, '_%s.cpp' % filenamebase)
            self.codeunits = [ SingleCodeUnit(self.modulename, fn, 'void Export_%s()' % utils.makeid(filenamebase)) ]
            self.myoutputs['']=self.codeunits[0]
            if splitoutputs.has_key(self.interface_file):
                n=1
                for definition in splitoutputs[interface_file]:
                    fn = os.path.join(self.filename, '_%s%d.cpp' % (filenamebase, n))
                    moduledef='void Export_%s%d()' % (utils.makeid(filenamebase), n)
                    cu=SingleCodeUnit(self.modulename, fn, moduledef)
                    self.myoutputs[definition]=cu
                    self.codeunits.append(cu)
                    n+=1
                #print "Definitions=",self.myoutputs


    def FunctionNames(self):
        'Returns the functions exporting this .pyste file'
        name = os.path.splitext(self.interface_file)[0]
        ret = [ 'Export_%s' % utils.makeid(name) ]
        for n in range(1, len(self.myoutputs)):
            ret.append('Export_%s%d' % (utils.makeid(name), n))
        return ret
    

    def FileNames(self):
        'Returns the .cpp files to codeunits exporting this .pyste file'
        ret = {}
        for output in self.codeunits:
            ret[output.filename]=output
        return ret

    
    def ExtractCurrentDef(self, code):
        'Extracts the definition the code is implementing'
        # Try class_ first
        classpos=re.compile('class_<(.+?)[,>]').search(code)
        if classpos:
            return classpos.group(1).strip()
        # Now try Wrapper
        wrapperpos=re.compile('struct .+?: (.+)').search(code)
        if wrapperpos:
            return wrapperpos.group(1).strip()
        return ""


    def Write(self, section, code):
        'write the given code in the section of the appropriate code unit'
        basecu=self.myoutputs['']
        if len(self.myoutputs)>1:
            currentdef=self.ExtractCurrentDef(code)
            #print "currentdef=",currentdef,"from",code.splitlines()[0]
            if self.myoutputs.has_key(currentdef):
                myoutput=self.myoutputs[currentdef]
                # If this would have been written into 'module', add a call
                if currentdef!='' and section=='module':
                    funct=myoutput.module_definition[5:]+';\n'
                    basecu.Write(section, '    // Call external definition of '+currentdef+'\n')
                    basecu.Write(section, '    '+funct+'\n')
                    basecu.module_definition='extern void '+funct+basecu.module_definition
            else:
                myoutput=basecu
        else:
            myoutput=basecu
        myoutput.Write(section, code)
        

    def Section(self, section):
        return self.code[section]


    def SetCurrent(self, *args):
        pass


    def Current(self):
        pass 

    
    def PrepareSave(self):
        'Prepares this code unit for saving'
        for cu in self.codeunits:
            if cu!=self.codeunits[0]:
                cu.CloneSections(self.codeunits[0])
